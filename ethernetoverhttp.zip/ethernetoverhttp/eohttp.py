from scapy.all import sniff, sendp, Ether
import requests
import threading
import time

INTERFACE = "br1"
SERVER_URL = "http://192.168.2.254"
POST_ENDPOINT = f"{SERVER_URL}/post.php"
GET_ENDPOINT = f"{SERVER_URL}/get.php"
POLL_INTERVAL = 0.01  # seconds

mat=[]

def relay_to_server(pkt):
    """
    Fonction appelée pour chaque trame capturée.
    Envoie la trame au serveur web via HTTP POST.
    """
    if Ether in pkt:
        if pkt[Ether].src not in mat :
            payload = bytes(pkt)
            try:
                files = {'file': ('frame.bin', payload)}
                response = requests.post(POST_ENDPOINT, files=files)
                if response.status_code != 200:
                    print(f"Erreur POST: {response.status_code}")
            except Exception as e:
                print(f"Erreur d'envoi POST: {e}")

def receive_from_server():
    """
    Boucle qui récupère les trames du serveur en GET et les réinjecte sur l'interface.
    """
    global mat
    while True:
        try:
            response = requests.get(GET_ENDPOINT)
            if response.status_code == 200 and response.content:
                ether_frame = Ether(response.content)
                if ether_frame.src not in mat :
                    mat.append(ether_frame.src)
                sendp(ether_frame, iface=INTERFACE, verbose=False)
        except Exception as e:
            print(f"Erreur GET: {e}")
        time.sleep(POLL_INTERVAL)

def main():
    print("Démarrage du relais bidirectionnel Ethernet <-> HTTP...")
    # Démarre le thread de réception
    threading.Thread(target=receive_from_server, daemon=True).start()
    # Lance la capture de paquets
    sniff(iface=INTERFACE, prn=relay_to_server, store=False)

if __name__ == "__main__":
    main()
