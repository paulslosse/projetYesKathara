<?php
$host = "localhost";
$db = "relay";
$user = "root";
$pass = "root";

// Connexion
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo "Erreur DB: " . $conn->connect_error;
    exit;
}

$client_ip = $_SERVER['REMOTE_ADDR'];

// Requête pour récupérer la trame la plus ancienne d’un autre client
$stmt = $conn->prepare("
    SELECT id, data FROM frame
    WHERE client_ip != ?
    ORDER BY timestamp ASC
    LIMIT 1
");
$stmt->bind_param("s", $client_ip);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $frame_id = $row['id'];
    $frame_data = $row['data'];

    // Supprimer la trame après lecture
    $del = $conn->prepare("DELETE FROM frame WHERE id = ?");
    $del->bind_param("i", $frame_id);
    $del->execute();
    $del->close();

    header("Content-Type: application/octet-stream");
    echo $frame_data;
} else {
    http_response_code(204); // Pas de contenu
}

$stmt->close();
$conn->close();
?>
