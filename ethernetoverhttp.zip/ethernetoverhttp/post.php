<?php
$host = "localhost";
$db = "relay";
$user = "root";
$pass = "root";

// Connexion à la base de données
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo "Erreur DB: " . $conn->connect_error;
    exit;
}

$client_ip = $_SERVER['REMOTE_ADDR'];

if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo "Fichier manquant.";
    exit;
}

$data = file_get_contents($_FILES['file']['tmp_name']);

// Préparer et exécuter l’insertion
$stmt = $conn->prepare("INSERT INTO frame (client_ip, data) VALUES (?, ?)");
$null = NULL;
$stmt->bind_param("sb", $client_ip, $null);
$stmt->send_long_data(1, $data);

if ($stmt->execute()) {
    echo "Trame enregistrée.";
} else {
    http_response_code(500);
    echo "Erreur d'insertion.";
}

$stmt->close();
$conn->close();
?>
