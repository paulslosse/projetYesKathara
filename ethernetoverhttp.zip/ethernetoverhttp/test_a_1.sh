#!/bin/bash
if test "`ps -edf | grep dhclient | grep enp0s3`" == "" ; then dhclient enp0s3 ; fi
ifconfig enp0s3
ifconfig enp0s10 192.168.2.1 netmask 255.255.255.0

ip link add name br1 type bridge
ip link set dev br1 up
ip link set dev enp0s8 up
ip link set dev enp0s8 master br1

python3 eohttp.py

